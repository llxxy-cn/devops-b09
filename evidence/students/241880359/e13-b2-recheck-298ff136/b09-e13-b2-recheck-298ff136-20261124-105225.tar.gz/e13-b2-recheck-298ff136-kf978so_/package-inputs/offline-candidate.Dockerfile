FROM b09-e13-offline-python:3.13-slim@sha256:af8922b2323b530a21bb406e3f38cae8488ad32f92555f27ab15538a7feb40b4
WORKDIR /work
COPY main.c helper.c config.h extra.h unused.h add.h sub.h calculate.h Makefile ./
RUN cp /opt/offline-toolchain/make /usr/bin/make && chmod 0755 /usr/bin/make
RUN make app
CMD ["./app"]
