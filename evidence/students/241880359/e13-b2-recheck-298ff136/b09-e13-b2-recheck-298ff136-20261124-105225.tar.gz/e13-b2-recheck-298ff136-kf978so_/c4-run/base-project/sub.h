int sub(int, int);
