# B2 教学样例部署与复现说明

负责人：黄新迪（241880359）

## 部署记录

2026 年 11 月 24 日，在课程服务器使用 Docker Compose 启动 API、worker、
Prometheus 和 Grafana。服务器直接拉取镜像超时，因此 API 与 worker 复用
本地已有的 Python 镜像，两个监控镜像通过离线包导入。

| 服务 | 实测镜像 | 首次部署宿主机端口 | 独立复现宿主机端口 |
|---|---|---|---|
| API | b09-e13-offline-python:3.13-slim | 18080 | 28080 |
| worker | b09-e13-offline-python:3.13-slim | 仅容器网络 | 仅容器网络 |
| Prometheus | prom/prometheus:v3.5.1 | 19090 | 29090 |
| Grafana | grafana/grafana:13.3.0 | 13000 | 23000 |

## 复现步骤

环境为 linux/amd64，需安装 Docker、Docker Compose 和 unzip。
在目标机器准备原始实验包 Microservice_Lab.zip 和三个镜像。
b2-monitoring-images.tar 只含 Prometheus 和 Grafana。
若目标机器缺少业务镜像，可在已有该镜像的服务器执行
`docker save -o b2-python-image.tar b09-e13-offline-python:3.13-slim`，
将文件传到目标机器后执行 `docker load -i b2-python-image.tar`。

在实验包和监控镜像包所在目录执行以下命令。三个宿主机端口需空闲。

```bash
docker load -i b2-monitoring-images.tar
docker image inspect b09-e13-offline-python:3.13-slim >/dev/null

REPRO_ROOT=$(mktemp -d)
unzip -q Microservice_Lab.zip -d "$REPRO_ROOT"
cd "$REPRO_ROOT/Microservice_Lab"

export COMPOSE_PROJECT_NAME="b2-repro-$(date +%Y%m%d-%H%M%S)"
export PYTHON_IMAGE=b09-e13-offline-python:3.13-slim
export LAB_API_PORT=28080 LAB_PROM_PORT=29090 LAB_GRAFANA_PORT=23000

docker compose config --quiet &&
docker compose up -d --pull never --wait --wait-timeout 90 &&
docker compose ps
```

## 验收方法与实测结果

```bash
curl -fsS http://127.0.0.1:28080/health
docker compose exec -T api python -c \
  "from urllib.request import urlopen; print(urlopen('http://worker:8080/health', timeout=5).read().decode())"
curl -fsS http://127.0.0.1:29090/-/ready
curl -fsS http://127.0.0.1:23000/api/health
curl -fsS 'http://127.0.0.1:29090/api/v1/targets?state=active'
```

11 月 25 日在同一服务器重新解压原始实验包，使用独立项目
b2-repro-20261125-110324、新网络和新数据卷完成复现，镜像复用本机缓存。
启动日志显示 worker 健康后 API 开始启动。API 和 worker 的健康响应均为 ok，
Prometheus 返回 Ready，Grafana 返回 database: ok。
Prometheus 对 lab-api 和 lab-worker 两个目标的抓取状态均为 up。

证据包中，b2-deploy-20261124/ 保存首次部署记录，
b2-reproduction/ 保存独立复现记录。可查看两轮的 images.txt、
prometheus-targets.json 和 startup.log，并用复现目录的 compose-up.txt
核对启动顺序。
